/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package banking;

//Merouane Issad
public interface ITransaction {

    /**
     * return the string that you want to output when printing the object
     */
    @Override
    String toString();
    //this is a test repos
    
}
